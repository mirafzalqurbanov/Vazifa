import os
os.system("cls")

class Tanishtir:
    def __init__(self, ism, familiya, yosh, ochestva):
        self.ism = ism
        self.familiya = familiya
        self.yosh = yosh
        self.ochestva = ochestva
    def Salomlash(self):
        return f"Salom mening ismim {self.ism}\nFamiliyam {self.familiya}\nOchestvam {self.ochestva}\nYoshim {self.yosh}  da"
class Kitob:
    def __init__(self, nom, bet, muallif, narx):
        self.nom = nom
        self.bet = bet
        self.muallif = muallif
        self.narx = narx
    def Sot(self):
        return f"Kitobning nomi {self.nom}\n{self.bet}  ta varoqli\nMuallifi:  {self.muallif}\nNarxi:   {self.narx}"
class Talaba:
    ismi = ""
    yoshi = ""
    baholari = 0
    kurs = 0
    def talaba(self):
        print(self.ismi)
        print(self.yoshi)
        print(self.baholari)
        print(self.kurs)
class Mashina:
    rusumi = ""
    yili = 0
    narxi = 0
    def mashina(self):
        print(self.rusumi)
        print(self.yili)
        print(self.narxi)
print("Tanishtiruv:")
tanishtir = Tanishtir("Mirafzal", "Qurbonov", 18, "Shuhrat og'li")
print(tanishtir.Salomlash())
print()
print("Kitoblar:")
kitob = Kitob("Ufq", 700, "Said Ahmad", 200.000)
print(kitob.Sot())
print()
print("Talaba:")
talaba1 = Talaba()
talaba1.ismi = "Islom Karimov"
talaba1.yoshi = 22
talaba1.baholari = 4
talaba1.kurs = 2
talaba1.talaba()
print()
print("Mashina:")
mashina1 = Mashina()
mashina1.rusumi = "BMW"
mashina1.yili = 2021
mashina1.narxi = 35.000
mashina1.mashina()