import os
import json
os.system("cls")

f = open("jj.json", "r")
mashinalar = json.load(f)
yil = sorted(mashinalar, key=lambda x: x['year'])

for i in yil:
    print(i)
