import os
os.system("cls")

def Sortlash(l):
    d = {}
    for i in l:
        if i in d:
            d[i] += 1
        else:
            d[i] = 1
    d1 = dict(sorted(d.items(), key=lambda i: i[1], reverse=True))
    print(d1)
l = [1, 1, 2, 3, 4, 5, 3, 2, 3, 4, 2, 1, 2, 3]
Sortlash(l)
