import os
import json
os.system("cls")

with open("nbu.json", "r", encoding="utf-8") as f:
    a = json.load(f)
davlat = sorted([i['title'] for i in a])
with open('nbu_davlatlar.json', 'w', encoding="utf-8") as f:
    json.dump(davlat, f, indent=4)